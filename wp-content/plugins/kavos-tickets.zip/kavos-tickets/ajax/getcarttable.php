<?php

require_once('../../../../wp-load.php'); // relative path from your PHP file

echo kbGetCartTable();